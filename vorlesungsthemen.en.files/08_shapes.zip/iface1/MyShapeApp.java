package vorlesung.iface1;

import java.util.ArrayList;
import java.util.List;

public class MyShapeApp {


    public static void main(String[] args) {

        List<Shape> list = new ArrayList<>();

        Shape shape1 = new Rectangle(3, 2);
        Shape shape2 = new Square(4);
        Shape shape3 = new Circle(2);

        list.add(shape1);
        list.add(shape2);
        list.add(shape3);

        for (Shape next : list) {
            System.out.println(next.getArea());
        }



    }

}
