package vorlesung.iface1;

public class Rectangle implements Shape {

    private double height;
    private double width;

    public Rectangle(double height, double width) {
        this.height = height;
        this.width = width;
    }

    @Override
    public double getCircumference() {
        return 2 * height + 2 * width;
    }

    @Override
    public double getArea() {
        return height * width;
    }

    // Flip 90 Grad
    public void flip() {
        double tmp = height;
        height = width;
        width = tmp;
    }
}

