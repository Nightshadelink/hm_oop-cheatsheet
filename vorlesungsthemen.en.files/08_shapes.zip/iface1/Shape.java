package vorlesung.iface1;

public interface Shape {

    /**
     * Umfang des Shapes.
     * @return Umfang.
     */
    double getCircumference();

    /**
     * Fläche des Shapes.
     * @return Fläche
     */
    double getArea();

}
