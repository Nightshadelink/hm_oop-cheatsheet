package vorlesung.iface3;

public class CopyShop {

    public static void main(String[] args) {

        boolean type = Boolean.parseBoolean(args[0]);

        // Kompaktere Variante
        Printable printable = createPrintable(type);
        doPrint(printable);

    }

    // Interface als Parameter
    static void doPrint(Printable printable) {
        printable.print();
    }



    // Interface Ergebnistyp
    static Printable createPrintable(boolean printableType) {
        // was muss hier rein?
        if (printableType) {
            return new Book("Stephen King", "Das ist ein spannender Text");
        }
        return new Poster("Miro", "********>>>>>>>>>////////");
    }

}
