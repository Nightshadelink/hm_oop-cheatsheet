package vorlesung.iface3;

public class Book implements Printable {

    private final String text;
    private final String author;

    public Book(String author, String text) {
        this.author = author;
        this.text = text;
    }

    @Override
    public void print() {
        System.out.println("Send to laser printer: " + text);
    }

}
