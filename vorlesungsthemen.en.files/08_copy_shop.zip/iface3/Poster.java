package vorlesung.iface3;

public class Poster implements Printable {

    private final String artist;
    private final String picture;

    public Poster(String artist, String picture) {
        this.artist = artist;
        this.picture = picture;
    }

    @Override
    public void print() {
        System.out.println("Print to Plotter: " + picture);
    }
}
