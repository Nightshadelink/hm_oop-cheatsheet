package vorlesung.iface3;

public interface Printable {

    void print();

}
