package vorlesung.enums;

// Enum public wegen Dateinamen Enum.java
public enum Day { MON, TUE, WED, THU, FRI, SAT(true), SUN(true);

    // Wochenende?
    private final boolean weekend;

    // Default-Konstruktor
    Day() {
        weekend = false;
    }

    // Custom-Konstruktor
    Day (boolean w) {
        weekend = w;
    }
    // Abfrage, ob es sich um Wochenende handelt
    boolean isWeekend() {
        return weekend;
    }
}

// Klasse darf in diesem Fall nicht mehr public sein.
// Andernfalls müsste die Datei DayMain heißen.
// Dann darf der Enum nicht mehr public sein.
class DayMain {

    public static void main(String[] args) {
        System.out.println(Day.MON.isWeekend());
        System.out.println(Day.SAT.isWeekend());
    }
}

