package vorlesung.enums;

public class SavingBox {

    public enum SavingBoxColor {
        RED, GREEN, BLUE, YELLOW
    }

    // Betrag im Sparschwein
    private double content = 0;

    // Farbe des Sparschweins
    private SavingBoxColor color;

    // Custom Konstruktor
    SavingBox(SavingBoxColor color){
        this.color = color;
    }

    // main-Methode in gleicher Klasse
    public static void main(String[] args) {
        // Zugriff auf Enum-Werte über Enumnamen
        SavingBoxColor color = SavingBoxColor.RED;
        SavingBox box = new SavingBox(color);
    }

}
