package vorlesung.enums;

public class Main {

    // Alternative main-Methode
    public static void main(String[] args) {
        // Zugrifff auf Enum-Werte über Klassennamen.Enumnamen
        SavingBox.SavingBoxColor color = SavingBox.SavingBoxColor.RED;
        SavingBox box = new SavingBox(color);
    }

}
