package vorlesung.enums;

enum Color {PINK, YELLOW, RED, BLUE, GREY}


public class Exercise {

    public static void main(String[] args) {

        // Letzte Farbe in Enum als String
        String lastColorAsString = Color.values()[Color.values().length - 1].toString();
        System.out.println(lastColorAsString);

        // Letzte Farbe im Enum als Color-Objekt
        Color lastColorAsObject = Color.values()[Color.values().length - 1];
        System.out.println(lastColorAsObject);

        // Ordinalzahl der Farbe RED =
        int redColorOrdinal = Color.RED.ordinal();
        System.out.println(redColorOrdinal);

        // Der String Yellow als Colorobjekt
        Color yellowStringAsObject = Color.valueOf("YELLOW");
        System.out.println(yellowStringAsObject);
    }
}
