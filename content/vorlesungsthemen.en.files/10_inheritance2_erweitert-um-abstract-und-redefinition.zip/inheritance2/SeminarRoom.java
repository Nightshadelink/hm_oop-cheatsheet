package vorlesung.inheritance2;

public class SeminarRoom extends Room {

    private static final String TYPE = "Sem_";
    private int capacity;

    public SeminarRoom(String roomName, int capacity) {
        super(roomName);
        this.capacity = capacity;
    }

    @Override
    public String getRoomName() {
        return TYPE + super.getRoomName();
    }

    public int getCapacity() {
        return capacity;
    }
}
