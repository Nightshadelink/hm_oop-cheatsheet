package vorlesung.inheritance2;

public class Lab extends Room {

    private static final String TYPE = "Lab_";

    private int nrComputer;

    public Lab(String roomName, int nrComputer) {
        super(roomName);
        this.nrComputer = nrComputer;
    }

    @Override
    public String getRoomName() {
        return TYPE + super.getRoomName();
    }

    public int getNrComputer() {
        return nrComputer;
    }
}
