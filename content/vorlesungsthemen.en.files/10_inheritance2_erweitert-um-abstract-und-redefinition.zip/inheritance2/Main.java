package vorlesung.inheritance2;

import java.util.ArrayList;
import java.util.List;

public class Main {


    public static void main(String[] args) {

        List<Room> rooms = new ArrayList<>();
        Room lab0 = new Lab("R2.009", 12);
        Room sem = new SeminarRoom("R2.009", 100);
        rooms.add(lab0);
        rooms.add(sem);

        for(Room next : rooms) {
            System.out.println(next.getRoomName());
        }


//
//        System.out.println(lab0.getRoomName());
//        System.out.println(sem.getRoomName());



//
//        Lab lab = new Lab("R2.010", 10);
//
//        rooms.add(lab);
//
//        Room seminar = new SeminarRoom("R1.007", 25);
//        rooms.add(seminar);
//
//        for (Room next: rooms) {
//            next.getRoomName();
//            next.getWalls();
//        }
//




    }
}
