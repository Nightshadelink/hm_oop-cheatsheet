package vorlesung.inheritance2;

public abstract class Room {

    private String roomName;
    private final int walls = 4;

    public Room(String roomName) {
        this.roomName = roomName;
    }

    // Variante mit abstrakter Methode
    // public abstract String getRoomName();

    // Variante mit normaler Methode, die in den
    // abgeleiteten Klassen redefiniert wird.
    public String getRoomName() {
        return roomName;
    }

    public int getWalls() {
        return walls;
    }

}
