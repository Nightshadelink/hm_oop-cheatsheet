package vorlesung.inheritance2;

public class Lab extends Room {

    private int nrComputer;

    public Lab(String roomNr, int nrComputer) {
        super(roomNr);
        this.nrComputer = nrComputer;
    }

    public int getNrComputer() {
        return nrComputer;
    }
}
