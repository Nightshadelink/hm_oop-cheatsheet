package vorlesung.inheritance2;

public class Room {

    private String roomNr;
    private int walls = 4;

    public Room(String roomNr) {
        this.roomNr = roomNr;
    }

    public String getRoomNr() {
        return roomNr;
    }

    public int getWalls() {
        return walls;
    }
}
