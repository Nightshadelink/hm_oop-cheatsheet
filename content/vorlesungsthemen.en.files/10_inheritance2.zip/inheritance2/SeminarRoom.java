package vorlesung.inheritance2;

public class SeminarRoom extends Room {

    private int capacity;

    public SeminarRoom(String roomNr, int capacity) {
        super(roomNr);
        this.capacity = capacity;
    }

    public int getCapacity() {
        return capacity;
    }
}
