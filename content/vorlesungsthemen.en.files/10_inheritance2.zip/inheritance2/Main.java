package vorlesung.inheritance2;

import java.util.ArrayList;
import java.util.List;

public class Main {


    public static void main(String[] args) {

        List<Room> rooms = new ArrayList<>();

        Lab lab = new Lab("R2.010", 10);
        rooms.add(lab);

        SeminarRoom seminar = new SeminarRoom("R1.007", 25);
        rooms.add(seminar);


        for (Room next: rooms) {
            next.getRoomNr();
            next.getWalls();
        }

        lab.getRoomNr();
        lab.getWalls();

        seminar.getRoomNr();
        seminar.getCapacity();
        seminar.getWalls();





    }
}
