package vorlesung.iface2;

public class MyClass implements MyInterface {

    private final int first;
    private final int second;


    MyClass(int first, int second) {
        this.first = first;
        this.second = second;
    }

    @Override
    public int getFirst() {	// Implementiert die abstrakte Methode getFirst im Interface
        return first;
    }


    @Override
    public int getSecond() {	// Implementiert die abstrakte Methode getSecond im Interface
        return second;
    }

}

