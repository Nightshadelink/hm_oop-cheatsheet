package vorlesung.iface2;

public interface MyInterface {

    int VALUE = 100;		// Konstante (public static final implizit festgelegt)

    int getFirst();		// Abstrakte Methode
    int getSecond();		// Abstrakte Methode

    // default Methode
    default int getSum() {
        return getFirst() + getSecond();
    }

    // statische Methode
    static int getBoundary() {
        return VALUE * VALUE;
    }
}
