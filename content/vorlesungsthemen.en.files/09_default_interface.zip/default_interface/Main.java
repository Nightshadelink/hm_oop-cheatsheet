package vorlesung.iface2;

public class Main {

    public static void main(final String[] args) {

        MyInterface c = new MyClass(2, 3);

        // Aufruf abstrakte Methode. Implementierung in der Klasse
        c.getFirst();

        // Aufruf abstrakte Methode. Implementierung in der Klasse
        c.getSecond();

        // Aufruf der Default-Methode aus Interface
        c.getSum();

        // Aufruf der statischen Methode aus dem Interface.
        // Weder auf Objekten, noch in der implementierender Klasse verfügbar.
        double result = MyInterface.getBoundary();

    }

}
