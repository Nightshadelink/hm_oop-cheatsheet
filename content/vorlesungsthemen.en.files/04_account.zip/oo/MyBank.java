public class MyBank {

    public static void main(String[] args) {

//        Account account1 = new Account();
//        Account account2 = new Account(12345);
//        Account account3 = new Account(67890, 300);
//        Account account4 = new Account();
//        Account account5 = new Account(678333);
//        Account account6 = new Account(34567, 400);

        Account account7 = new Account();
        if (account7 != null) {
            int tmp = 3; // Gültig bis schließende geschweifte Klammer
            account7.deposit(300);
        } else {
            int tmp = 4;
            System.out.println("Kein Objekt vorhanden");
        }
        account7.withdraw(300);
        

//
//        account1.deposit(1000);
//        account2.deposit(500);
//
//        double currentBalance = account1.getBalance();
//
//        account2.deposit(currentBalance);
//
//        System.out.println(currentBalance);
//
//        account1.withdraw(300);
//        account2.deposit(200);
    }


}
