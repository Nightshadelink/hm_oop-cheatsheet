import java.util.Random;

class Account {

    // Kontonummer
    private int accountNumber;

    // aktueller Kontostand
    private double balance = 0; // Objektvariable

    // Default-Konstruktor
    Account() {
        accountNumber = new Random().nextInt(100000);
    }

    // Custom-Konstruktor
    Account(int accountNumber) {
        this.accountNumber = accountNumber;
    }

    // Custom Constructor
    Account(int accountNr, double initBalance) {
        accountNumber = accountNr;
        balance = initBalance;
    }

    // Einzahlungen in das Konto
    void deposit(final double amount) { // Parameter
        double tmp = balance + amount; // Lokale Variable
        balance = tmp;
        // Alternativ (und kürzer):
        // balance = balance + amount;
    }

    // Abfrage des aktuellen Kontostands
    double getBalance() {
        return balance;
    }

    // Abheben eines Betrags. Gibt aktuellen Kontostand zurück.
    double withdraw(double amount) {
        balance -= amount;
        return balance;
    }

}
