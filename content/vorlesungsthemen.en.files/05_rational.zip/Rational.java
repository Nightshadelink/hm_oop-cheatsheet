package vorlesung.rational;


/**
 * Eine Rationale Zahl ist reelle Zahl, die als Verhältnis (lateinisch ratio)
 * zweier ganzer Zahlen dargestellt werden kann.
 *
 * @author Ulrike Hammerschall
 */
public class Rational {

    // veränderliche Objektvariable für Zähler
    private int num;

    // veränderliche Objektvariable für Nenner
    private int denom;

    // Custom-Konstruktor mit Methodenaufruf
    public Rational(int num, int denom) {
       setRational(num, denom);
    }

    // Custom-Konstruktor mit Constructor-Chaining
    public Rational(int num) {
        this(num, 2);
    }

    // Default-Konstruktor mit Constructor-Chaining
    public Rational() {
       this(1);
    }

    // Copy-Konstruktor mit Constructor-Chaining
    public Rational(Rational orig) {
        this(orig.getNum(), orig.getDenom());
    }

    // setRational mit vollständiger Implementierung
    public void setRational(int num, int denom) {
        if (denom == 0) {
            // noch nicht bekannt
            throw new IllegalArgumentException();
        }
        this.num = num;
        this.denom = denom;
        reduce();
    }

    // Überladen von setRational
    public void setRational(int num) {
        setRational(num, 2);
    }

    // Überladen von setRational
    public void setRational() {
        setRational(1, 2);
    }

    // Getter für Zähler
    public int getNum() {
        return num;
    }

    // Getter für Nenner
    public int getDenom() {
        return denom;
    }

    @Override
    public String toString() {
        return getNum() + " / " + getDenom();
    }

    // Private Hilfsmethoden zum Kürzen
    private void reduce() {
        int ggt = ggt(num, denom);
        this.num = num / ggt;
        this.denom = denom / ggt;
    }

    // Berechnung des größten gemeinsamen Teilers
    private int ggt(int a, int b) {
        int a1 = Math.abs(a);
        int b1 = Math.abs(b);
        while (a1 != b1) {
            if (a1 > b1) {
                a1 = a1 - b1;
            } else {
                b1 = b1 - a1;
            }
        }
        return a1;
    }

}





















