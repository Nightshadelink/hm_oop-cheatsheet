package vorlesung.rational;

public class RationalMain {

    public static void main(String[] args) {

        // Verwendung der verschiedenen überladenen Konstruktoren
        Rational rational = new Rational(1,2);
        Rational rational1 = new Rational(5);
        Rational rational2 = new Rational();

        // Verwendung des Copy-Konstruktors
        Rational copy = new Rational(rational2);
        System.out.println(copy.toString());
        System.out.println(rational2.toString());

        // Verwendung der überladenen Methode setRational
        rational.setRational();
        rational.setRational(3);
        rational.setRational(3,5);

    }
}
